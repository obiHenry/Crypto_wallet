package com.example.Crypto_wallet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
