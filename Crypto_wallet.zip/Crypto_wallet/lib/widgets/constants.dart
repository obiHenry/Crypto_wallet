import 'package:flutter/material.dart';

const kPrimaryColor = Color(0x0000FF);
const kPrimaryLightColor = Color(0xadd8e6);

const kTextColor = Color(0xFF535353);
const kTextLightColor = Color(0xFFACACAC);

const kDefaultPaddin = 20.0;
