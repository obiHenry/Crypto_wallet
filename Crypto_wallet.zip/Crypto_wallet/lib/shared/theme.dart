import 'package:flutter/material.dart';

final appTheme = ThemeData(
  primarySwatch: Colors.lightGreen,
  // accentColor: 
  // fontFamily: 'Rubik',
);