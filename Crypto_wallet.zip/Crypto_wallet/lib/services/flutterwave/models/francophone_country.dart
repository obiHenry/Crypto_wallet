class FrancoPhoneCountry {
  final String name;
  final String countryCode;

  FrancoPhoneCountry(this.name, this.countryCode);
}