class UserM {
  final String uid;
  UserM({this.uid});
}