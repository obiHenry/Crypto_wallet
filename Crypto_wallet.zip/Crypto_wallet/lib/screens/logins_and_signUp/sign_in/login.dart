import 'package:Crypto_wallet/screens/logins_and_signUp/sign_in/body.dart';
import 'package:flutter/material.dart';

class Login extends StatelessWidget {
  static const routeName = '/login';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}