import 'package:Crypto_wallet/screens/logins_and_signUp/set_up/body.dart';
import 'package:flutter/material.dart';

class SetUpScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}